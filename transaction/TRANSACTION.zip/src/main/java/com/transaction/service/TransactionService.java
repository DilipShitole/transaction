package com.transaction.service;


import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import com.transaction.model.TransactionModel;
import com.transaction.model.response.AccountDetails;
import com.transaction.model.response.AccountSummary;
import com.transaction.model.response.Customer;

import com.transaction.repository.TransactionRepository;



@Service
public class TransactionService {

	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Value("${account_details_byid}")
	private String account_summary_url;
	
	@Value("${update_account_balance}")
	private String update_account_balance;

	public TransactionModel saveTransaction(TransactionModel transactionModel) {
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:MM:ss");
		String requiredDate = df.format(new Date(System.currentTimeMillis()));
		transactionModel.setDate(requiredDate);
		transactionRepository.save(transactionModel);
		return transactionModel;
	}

	public List<TransactionModel> getAllTransactions() {
		List<TransactionModel> transactionlist = transactionRepository.findAll();
		return transactionlist;
	}

	public String deleteById(String transaction_id) {
		transactionRepository.deleteById(transaction_id);
		return "Transaction Deleted Successfully";
	}

	public TransactionModel updateById(String transaction_id, TransactionModel transactionModel) {
		Optional<TransactionModel> transactionModel1 = transactionRepository.findById(transaction_id);
		TransactionModel transactionModel2 = transactionModel1.get();

		transactionModel2.setTransaction_id(transactionModel.getTransaction_id());
		transactionModel2.setAccount(transactionModel.getAccount());
		transactionModel2.setTo_account(transactionModel.getTo_account());
		transactionModel2.setTransaction_amount(transactionModel.getTransaction_amount());
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:MM:ss");
		String requiredDate = df.format(new Date(System.currentTimeMillis()));
		transactionModel2.setDate(requiredDate);
		transactionRepository.save(transactionModel2);

		return transactionModel2;
	}

	public AccountSummary getTrnactionDetails(String account) {
		HttpHeaders header=new HttpHeaders();
		   HttpEntity<AccountSummary> entity=new HttpEntity<AccountSummary>(header);
		   Map<String, String> vars = new HashMap<>();
		   vars.put("account",account);
		   ResponseEntity<AccountSummary> accSummary= restTemplate.exchange(account_summary_url, HttpMethod.GET,entity,AccountSummary.class,vars);
		   Optional<List<TransactionModel>> TRS=transactionRepository.getTransactionsByAccount( account);
			List<TransactionModel> tranList=TRS.get();
		   AccountSummary accSummary1=accSummary.getBody();
		   accSummary1.setTransactionModel(tranList);
		   return accSummary1;
		
	  
		
	}

//	public void transferFund(String from_account, Float amount, String to_account) {
//		// step 1 fetch from account details and balance to validate amount
//				// step 2 fetch to account details and add balance into to account details
//				// step 3 generate account transaction and save into transaction table
//				// step 4 update account table with latest balance 
//		AccountSummary accSum=getTrnactionDetails(from_account);
//		Float from_account_balance=accSum.getAccountDetails().getBalance();
//		AccountSummary accSum1=getTrnactionDetails(to_account);
//		Float to_account_balance=accSum1.getAccountDetails().getBalance();
//		Float balance_update=accSum1.getAccountDetails().getBalance()+amount;
//		if(from_account_balance>amount) {		
//			ResponseEntity<String> response=updateBalanceInAccountService(to_account,balance_update);
//			System.out.println("get status code value"+response.getStatusCodeValue());
//			if(response.getStatusCodeValue()==200) {				
//				updateBalanceInAccountService(from_account,from_account_balance-amount);
//				
//				// update transaction with new transaction details 
//				TransactionModel transactionModel=new TransactionModel();
//				transactionModel.setFrom_account(from_account);
//				transactionModel.setTo_account(to_account);
//				transactionModel.setTransaction_amount(amount);
//				transactionModel.setAccount(from_account);
//				String transaction_id=Double.toString(Math.random());
//				transactionModel.setTransaction_id(transaction_id);
//				transactionRepository.save(transactionModel);
//			}
//		}
//	}
//	
//	public ResponseEntity<String> updateBalanceInAccountService(String account_id,Float balance){
//		   HttpHeaders header=new HttpHeaders();
//		   HttpEntity<AccountSummary> entity=new HttpEntity<AccountSummary>(header);
//		   Map<String, Object> vars = new HashMap<>();
//		   vars.put("account_id",account_id);
//		   vars.put("balance",balance);
//		   ResponseEntity<String> accSummary= restTemplate.exchange(update_account_balance, HttpMethod.PUT,entity,String.class,vars);
//		return accSummary;
//	}
}
